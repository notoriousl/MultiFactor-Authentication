# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('select/', views.select_and_display, name='select_and_display'),
]
