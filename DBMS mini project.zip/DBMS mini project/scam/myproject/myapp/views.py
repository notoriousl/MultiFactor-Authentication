from django.shortcuts import render, get_object_or_404
from .models import Student

def student_detail(request, student_id):
    student = get_object_or_404(Student, pk=student_id)
    return render(request, 'student_detail.html', {'student': student})
def home(request):
    return HttpResponse("Welcome to my app!")