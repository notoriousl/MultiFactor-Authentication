from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Root path redirects to the 'home' view
    path('student/<int:student_id>/', views.student_detail, name='student_detail'),
    # Other URL patterns for your app
]
