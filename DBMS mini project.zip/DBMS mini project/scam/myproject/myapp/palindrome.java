class Solution {
    static boolean isPalindrome(int x) {
        int a=0;
        int test;
        test=x;
        if(x<0)
        {
            return false;
        }
        else
        {
            while(test!=0)
            {
                test=test%10;
                a++;
            }
            return true;
        }
        
    }
    public static void main(String args[])
    {
        boolean b=isPalindrome(101);
        System.out.println(b);
    }
}