from django.contrib import admin

# Register your models here.

from . models import Record,Owner_info,Vehicle_info,type_of_veh,Department,Gender

admin.site.register(Record)

admin.site.register(Owner_info)

admin.site.register(Vehicle_info)

admin.site.register(Department)

admin.site.register(type_of_veh)

admin.site.register(Gender)

