from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Record,Vehicle_info,Owner_info

from django import forms

from django.contrib.auth.forms import AuthenticationForm
from django.forms.widgets import PasswordInput, TextInput

# - Register/Create a user

class CreateUserForm(UserCreationForm):

    class Meta:

        model = User
        fields = ['username', 'password1', 'password2']


# - Login a user

class LoginForm(AuthenticationForm):

    username = forms.CharField(widget=TextInput())
    password = forms.CharField(widget=PasswordInput())


# - Create a record

class CreateRecordForm(forms.ModelForm):

    class Meta:

        model = Record
        fields = ['Vehicle', 'Licence' ,'College_ID', 'Gate_IN', 'Time_in', 'Gate_Out', 'Time_Out']


# - Update a record

class UpdateRecordForm(forms.ModelForm):

    class Meta:

        model = Record
        fields =  ['Gate_Out', 'Time_Out']

class VehicleCreate(forms.ModelForm):

    class Meta:

        model=Vehicle_info
        fields=['L_Plate','V_Model','Type','Color','Fuel_type','Owner_id']

class DriverCreate(forms.ModelForm):
    class Meta:

        model=Owner_info
        fields=['ID','full_name','department','Gender','Role','phone']