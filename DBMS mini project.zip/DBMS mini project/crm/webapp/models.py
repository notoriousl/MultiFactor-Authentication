from django.db import models


class Gender(models.Model):
    
    gender=models.CharField(primary_key=True,max_length=100)

    def __str__(self):
        return self.gender

class Department(models.Model):

    dept=models.CharField(primary_key=True,max_length=100)

    def __str__(self):
        return self.dept

class Owner_info(models.Model):

    ID=models.CharField(primary_key=True,max_length=100)

    full_name = models.CharField(max_length=100,null=True)


    department=models.ForeignKey(Department,null=True,on_delete=models.CASCADE)

    Gender=models.ForeignKey(Gender,null=True,on_delete=models.CASCADE)

    Role=models.CharField(max_length=100,null=True)

     

    phone = models.IntegerField(null=True)

    def __str__(self):
        return self.ID
     

     
class type_of_veh(models.Model):

    type=models.CharField(primary_key=True,max_length=15)
    def __str__(self):
        return self.type



class Vehicle_info(models.Model):

    L_Plate=models.CharField(max_length=100,primary_key=True)

    V_Model=models.CharField(max_length=100)
    
    Type=models.CharField(max_length=250)

    Color=models.CharField(max_length=150)

    Fuel_type=models.CharField(max_length=100,blank=True)

    Owner_id=models.ForeignKey(Owner_info,null=True,on_delete=models.CASCADE)

    def __str__(self):
        return self.L_Plate
     

class Record(models.Model):

    creation_date = models.DateTimeField(auto_now_add=True)

    College_ID=models.ForeignKey(Owner_info,related_name='LOOLL',on_delete=models.CASCADE)

    Licence=models.ForeignKey(Vehicle_info,null=True,on_delete=models.CASCADE)

    Vehicle=models.ForeignKey(type_of_veh,null=True,blank=True,on_delete=models.CASCADE)

    Gate_IN=models.IntegerField(null=True)

    Time_in=models.DateTimeField(null=True)

    Gate_Out=models.IntegerField(null=True,blank=True)

    email=models.CharField(max_length=100)

    Time_Out=models.DateTimeField(null=True,blank=True)





    #ID=models.ForeignKey(Owner_info,on_delete=models.CASCADE,null=True)


    def __str__(self):

        return self.College_ID

 

    


















